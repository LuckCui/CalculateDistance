//
//  CJZCalculateDistance.m
//  CJZCalculateDistance
//
//  Created by CuiJianZhou on 15/12/10.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import "CJZCalculateDistance.h"

@implementation CJZCalculateDistance

+(double)distanceBetweenOrderBy:(double)lat1 :(double)lng1 :(double)lat2 :(double)lng2{
    
    double dd = M_PI/180;
    double x1=lat1*dd,x2=lat2*dd;
    double y1=lng1*dd,y2=lng2*dd;
    double R = 6371004;
    double distance = (2*R*asin(sqrt(2-2*cos(x1)*cos(x2)*cos(y1-y2) - 2*sin(x1)*sin(x2))/2));
    //km  返回
    //     return  distance*1000;
    
    //返回 m
    return   distance;
    
}

@end
