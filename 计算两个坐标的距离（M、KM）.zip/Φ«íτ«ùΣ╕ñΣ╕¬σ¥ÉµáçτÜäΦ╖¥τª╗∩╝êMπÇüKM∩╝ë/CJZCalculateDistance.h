//
//  CJZCalculateDistance.h
//  CJZCalculateDistance
//
//  Created by CuiJianZhou on 15/12/10.
//  Copyright © 2015年 CJZ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CJZCalculateDistance : NSObject

+(double)distanceBetweenOrderBy:(double)lat1 :(double)lng1 :(double)lat2 :(double)lng2;

@end
